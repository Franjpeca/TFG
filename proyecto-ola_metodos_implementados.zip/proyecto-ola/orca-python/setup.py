from setuptools import setup

# from malenia import __version__

setup(
    name='orca_python',
    version="0.0.1",

    url='https://github.com/ayrna/orca-python',
    author='AYRNA',
    author_email='ayrna@gmail.com', # no existe ese correo

    py_modules=['orca_python'],

    # entry_points = {
    #     'console_scripts': [
    #         'malenia_check_condor_errors = malenia:check_condor_errors',
    #         'malenia_test = malenia:test',
    #     ],            
    # },
)
