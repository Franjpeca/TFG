"""proyecto_ola"""

__version__ = "0.1"

from .pipeline_registry import register_pipelines

