#include "Python.h"

PyObject* fit(PyObject* self, PyObject* args);
PyObject* predict(PyObject* self, PyObject* args);
